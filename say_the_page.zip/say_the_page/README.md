# Say The Page

A minimal Android app that loads a local HTML file with a counter and Russian text-to-speech using WebView.

## Features

- Counter with increment and custom value
- Speak current page number (in Russian)
- Additional speaking buttons for custom phrases
- Voice selection (browser voices)
- All logic and UI in a single HTML file

## How to use

1. **Clone this repository.**
2. Open in Android Studio (File > Open > select the project folder).
3. Build the APK:  
   - From the menu: **Build > Build APK(s)**
   - Or run on a device/emulator directly
4. The app opens your `PageSpeak.html` from assets in a WebView.

## File structure

- `app/src/main/assets/PageSpeak.html` — your HTML/JS/CSS
- `app/src/main/java/com/example/saythepage/MainActivity.kt` — minimal WebView host
- Standard Android build files

## Customization

Replace/edit `PageSpeak.html` to update the UI or logic.

---

**MIT License**